title: Spring AOP @Aspect的使用记录
date: '2019-05-28 16:32:14'
updated: '2019-05-28 16:32:14'
tags: [JAVA]
permalink: /articles/2019/05/28/1559032334679.html
---
今天在写项目的时候想给项目添加请求的耗时以及请求的参数打印，经过查找想使用Spring  AOP中的Aspect功能
首先需要自定义一个类，然后需要给类加两个注解  一个是`@Aspect`  另一个是 `@Component` 因为需要把它加入spring的容器进行管理，所以这个注解是必须的，其次如果第一个注解引用不到需要导入`spring-boot-starter-aop`的依赖
```
	<dependency>
                <groupId>org.springframework.boot</groupId>
		<artifactId>spring-boot-starter-aop</artifactId>
	</dependency>
```
考虑到业务需求，需要在请求的前后都打印一次日志，所以使用了注解 @Around   具体代码如下

```
package com.test.mail.demo.filter;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;


/**
 * Created by 宋维飞
 * 2019/5/28 15:22
 */
@Aspect
@Component
public class LogAspect {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Pointcut("execution(public * com.test.mail.demo.controller..*.*(..))")
    public void controllerLog() {
    }

    @Around("controllerLog()")
    public Object doAround(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        MethodSignature ms = (MethodSignature) joinPoint.getSignature();
        logger.info("**log-start** CLASS:{},METHOD:{},PARAMS:{}", joinPoint.getTarget().getClass().getName(),
                ms.getMethod().getName(), joinPoint.getArgs());
        Object ret = joinPoint.proceed(joinPoint.getArgs());
        logger.info("**log-end  ** CLASS:{},METHOD:{},USETIME:{}ms", joinPoint.getTarget().getClass().getName(),
                ms.getMethod().getName(), System.currentTimeMillis() - start);
        return ret;
    }

}

```
测试controller类代码如下

```
package com.test.mail.demo.controller;



import org.slf4j.Logger;

import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by 宋维飞
 * 2019/5/28 15:06
 */
@RestController
public class TestController {

    private  static  final Logger logger= LoggerFactory.getLogger(TestController.class);

    @RequestMapping("/test")
    public  String say(String name){
        logger.info("进入测试类");
        return  "ok "+name;
    }
}

```
启动项目  访问  http://127.0.0.1:8080/test?name=张三
打印日志如下:


```
2019-05-28-16:29:47.171 INFO [http-nio-8080-exec-1]-c.t.m.d.f.LogAspect:31[d126a3b6d4ef4224b4f9d6da3c6c5e87]>>**log-start** CLASS:com.test.mail.demo.controller.TestController,METHOD:say,PARAMS:[张三]

2019-05-28-16:29:47.180 INFO [http-nio-8080-exec-1]-c.t.m.d.c.TestController:19[d126a3b6d4ef4224b4f9d6da3c6c5e87]>>进入测试类
2019-05-28-16:29:47.181 INFO [http-nio-8080-exec-1]-c.t.m.d.f.LogAspect:34[d126a3b6d4ef4224b4f9d6da3c6c5e87]>>**log-end  ** CLASS:com.test.mail.demo.controller.TestController,METHOD:say,USETIME:12ms
```
