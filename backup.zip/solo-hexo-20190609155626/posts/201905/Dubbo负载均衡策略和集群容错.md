title: Dubbo 负载均衡策略和集群容错
date: '2019-05-13 15:10:44'
updated: '2019-05-13 15:11:52'
tags: [Dubbo]
permalink: /articles/2019/05/13/1557731444338.html
---
> 本文转载自github用户[yanglbme](https://github.com/yanglbme)原文链接https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md

### 基本问题点
*   dubbo 工作原理：服务注册、注册中心、消费者、代理通信、负载均衡；
*   网络通信、序列化：dubbo 协议、长连接、NIO、hessian 序列化协议；
*   负载均衡策略、集群容错策略、动态代理策略：dubbo 跑起来的时候一些功能是如何运转的？怎么做负载均衡？怎么做集群容错？怎么生成动态代理？
*   dubbo SPI 机制：你了解不了解 dubbo 的 SPI 机制？如何基于 SPI 机制对 dubbo 进行扩展？
### dubbo 负载均衡策略
#### random loadbalance

默认情况下，dubbo 是 random load balance ，即**随机**调用实现负载均衡，可以对 provider 不同实例**设置不同的权重**，会按照权重来负载均衡，权重越大分配流量越高，一般就用这个默认的就可以了。

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#roundrobin-loadbalance)roundrobin loadbalance

这个的话默认就是均匀地将流量打到各个机器上去，但是如果各个机器的性能不一样，容易导致性能差的机器负载过高。所以此时需要调整权重，让性能差的机器承载权重小一些，流量少一些。

举个栗子。

跟运维同学申请机器，有的时候，我们运气好，正好公司资源比较充足，刚刚有一批热气腾腾、刚刚做好的虚拟机新鲜出炉，配置都比较高：8 核 + 16G 机器，申请到 2 台。过了一段时间，我们感觉 2 台机器有点不太够，我就去找运维同学说，“哥儿们，你能不能再给我一台机器”，但是这时只剩下一台 4 核 + 8G 的机器。我要还是得要。

这个时候，可以给两台 8 核 16G 的机器设置权重 4，给剩余 1 台 4 核 8G 的机器设置权重 2。

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#leastactive-loadbalance)leastactive loadbalance

这个就是自动感知一下，如果某个机器性能越差，那么接收的请求越少，越不活跃，此时就会给**不活跃的性能差的机器更少的请求**。

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#consistanthash-loadbalance)consistanthash loadbalance

一致性 Hash 算法，相同参数的请求一定分发到一个 provider 上去，provider 挂掉的时候，会基于虚拟节点均匀分配剩余的流量，抖动不会太大。**如果你需要的不是随机负载均衡**，是要一类请求都到一个节点，那就走这个一致性 Hash 策略。
### dubbo 集群容错策略
#### failover cluster 模式

失败自动切换，自动重试其他机器，默认就是这个，常见于读操作。（失败重试其它机器）

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#failfast-cluster%E6%A8%A1%E5%BC%8F)failfast cluster模式

一次调用失败就立即失败，常见于写操作。（调用失败就立即失败）

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#failsafe-cluster-%E6%A8%A1%E5%BC%8F)failsafe cluster 模式

出现异常时忽略掉，常用于不重要的接口调用，比如记录日志。

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#failback-cluster-%E6%A8%A1%E5%BC%8F)failback cluster 模式

失败了后台自动记录请求，然后定时重发，比较适合于写消息队列这种。

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#forking-cluster-%E6%A8%A1%E5%BC%8F)forking cluster 模式

**并行调用**多个 provider，只要一个成功就立即返回。

#### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#broadcacst-cluster)broadcacst cluster

逐个调用所有的 provider。

### [](https://github.com/doocs/advanced-java/blob/master/docs/distributed-system/dubbo-load-balancing.md#dubbo%E5%8A%A8%E6%80%81%E4%BB%A3%E7%90%86%E7%AD%96%E7%95%A5)dubbo动态代理策略

默认使用 javassist 动态字节码生成，创建代理类。但是可以通过 spi 扩展机制配置自己的动态代理策略。