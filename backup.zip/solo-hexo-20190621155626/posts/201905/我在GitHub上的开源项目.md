title: 我在 GitHub 上的开源项目
date: '2019-05-19 15:57:15'
updated: '2019-05-19 15:57:15'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [SchoolShops](https://github.com/librarysong/SchoolShops) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/SchoolShops/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/librarysong/SchoolShops/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/SchoolShops/network/members "分叉数")</span>

一个简单的校园商铺系统



---

### 2. [ssm-curd](https://github.com/librarysong/ssm-curd) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/ssm-curd/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/librarysong/ssm-curd/stargazers "收藏数")&nbsp;&nbsp;[🖖`1`](https://github.com/librarysong/ssm-curd/network/members "分叉数")</span>

简单的SSM框架整合



---

### 3. [sell](https://github.com/librarysong/sell) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/sell/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/librarysong/sell/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/sell/network/members "分叉数")</span>

微信点餐平台开发

