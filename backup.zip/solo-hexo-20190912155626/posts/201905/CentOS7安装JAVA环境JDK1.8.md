title: CentOS 7 安装 JAVA环境（JDK 1.8)
date: '2019-05-10 11:46:06'
updated: '2019-05-10 16:12:04'
tags: [Linux]
permalink: /articles/2019/05/10/1557459966891.html
---
## 下载 
 首先从oracle官网下载安装包，或者通过wget方式进行下载
wget下载的链接:

`https://download.oracle.com/otn/java/jdk/8u211- b12/478a62b7d4e34b78b671c754eaaf38ab/jdk-8u211-linux-x64.tar.gz?AuthParam=1557459967_b585cdbbd8464a55825d5b2544d63eb2`
## 安装
创建安装目录
`mkdir /usr/local/java/`
解压至安装目录
`tar -zxvf jdk-8u211-linux-x64.tar.gz -C /usr/local/java/`
## 设置环境变量
打开文件
`vim /etc/profile`

在末尾添加
`export JAVA_HOME=/usr/local/java/jdk-8u211`
`export JRE_HOME=${JAVA_HOME}/jre`
`export CLASSPATH=.:${JAVA_HOME}/lib:${JRE_HOME}/lib`
`export PATH=${JAVA_HOME}/bin:$PATH`

使环境变量生效

`source /etc/profile`

添加软链接

`ln -s /usr/local/java/jdk-8u211/bin/java /usr/bin/java`

检查版本 输入  java -version

![TIM截图20190510134935.jpg](https://img.hacpai.com/file/2019/05/TIM截图20190510134935-3e7c5d4a.jpg)


