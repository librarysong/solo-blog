title: IntelliJ IDEA 内存配置
date: '2019-08-05 16:59:46'
updated: '2019-08-05 16:59:46'
tags: [JVM]
permalink: /articles/2019/08/05/1564995586110.html
---
### 基本情况介绍
1、机器使用的Intel(R) Xeon(R) CPU E5-2640@2.5GHZ   32GB内存
2、操作系统 Windwos Server 2003
3、idea版本使用的2018.1  测试是打开5个工程

### 调优情况
1、只调整堆内存
```
-server
-Xms 4096m
-Xms 4096m
```
仅仅调整了一下堆内存的大小，启动项目查看，发现大约发生了十几次的YGC ，1次Full GC ，大约整体的GC耗时 7秒多，仅仅一次Full  GC 就占了 3秒钟  所以需要先消灭这一次Full GC，通过jstat查看内存占用  发现老年代其实一直没有被填满，理论上不应该发生Full GC，所以只有一种可能，那就是有程序显示调用了System.gc() ，通过参数-XX:+DisableExplicitGC 关闭以后 再次启动，发现这一次Full  GC  没有了 GC总时间下降到3秒多

2、降低新生代GC次数
虽然老年的GC解决了 ，但是新生代的YGC次数还是很多，高达十几次，通过查看新生代的回收情况，发现发生YGC的原因都是新生代满了进行的清理，新生代满的原因是idea启动的时候会加载很多对象   但是新生代使用的默认参数，虽然堆大小设置为4G  但是新生代仅仅只有eden仅有不到1G内存，所有导致新生代很快被填满，发生了YGC，而老年代一直占用很少，所以要调整一下新生代的大小
```
-Xms4096m
-Xmx4096m
-Xmn3072m
-XX:+DisableExplicitGC
```
通过调整新生代的大小 YGC的次数明显降低
```
S0C    S1C    S0U    S1U      EC       EU        OC         OU       MC     MU CCSC   CCSU   YGC     YGCT    FGC    FGCT     GCT

314560.0 314560.0  0.0   273090.5 2516608.0 1536459.0 1048576.0   355034.3  288000.0 269258.7 39424.0 35338.6      5    2.035   0      0.000    2.035
```
启动完成仅仅进行了5次YGC  总耗时 2.035秒
3、整体参数
```
-server

-Xms4096m
-Xmx4096m
-Xmn3072m
-XX:+DisableExplicitGC
-XX:+UseCMSInitiatingOccupancyOnly
-XX:CMSInitiatingOccupancyFraction=75
-XX:ReservedCodeCacheSize=1024m
-XX:+UseConcMarkSweepGC
-XX:SoftRefLRUPolicyMSPerMB=50
-ea
-Dsun.io.useCanonCaches=false
-Djava.net.preferIPv4Stack=true
-XX:+HeapDumpOnOutOfMemoryError
-XX:-OmitStackTraceInFastThrow
-XX:MetaspaceSize=512m
-XX:MaxMetaspaceSize=1024m
```

4、使用G1收集器
G1收集器使用可预测的停顿模型，他会记录每个region的内存占用以及回收该区块的价值，通过
-XX:MaxGCPauseMillis=250  参数指定希望每次垃圾收集停顿的时间，G1会保证在用户指定的时间内进行垃圾回收
参数：
```
-server
-Xms4096m
-Xmx4096m
-XX:MaxGCPauseMillis=250
-XX:+DisableExplicitGC
-XX:+UseG1GC
-XX:ReservedCodeCacheSize=1024m
-XX:SoftRefLRUPolicyMSPerMB=50
-ea
-Dsun.io.useCanonCaches=false
-Djava.net.preferIPv4Stack=true
-XX:+HeapDumpOnOutOfMemoryError
-XX:-OmitStackTraceInFastThrow
-XX:MetaspaceSize=1024m
-XX:MaxMetaspaceSize=1024m
```
使用G1收集器以后  通过jstat查看
```
 S0C    S1C    S0U    S1U      EC       EU        OC         OU       MC     MU CCSC   CCSU   YGC     YGCT    FGC    FGCT     GCT

 0.0   28672.0  0.0   28672.0 1544192.0 364544.0 2621440.0   572174.6  283264.0 264828.0 38784.0 34780.4     17    2.130   0      0.000    2.130
```
可以看到效果也是很明显的 虽然YGC次数很多 ，但是每次都是在指定的时间内完成，通过多次收集达到效果，时间占用也很低，同时没有明显的停顿。