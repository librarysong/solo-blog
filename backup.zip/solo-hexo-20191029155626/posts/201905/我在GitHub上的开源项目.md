title: 我在 GitHub 上的开源项目
date: '2019-05-19 15:57:15'
updated: '2019-05-19 15:57:15'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [SchoolShops](https://github.com/librarysong/SchoolShops) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/SchoolShops/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/librarysong/SchoolShops/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/SchoolShops/network/members "分叉数")</span>

一个简单的校园商铺系统



---

### 2. [ssm-curd](https://github.com/librarysong/ssm-curd) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/ssm-curd/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/librarysong/ssm-curd/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/ssm-curd/network/members "分叉数")</span>

简单的SSM框架整合



---

### 3. [practice-cloud](https://github.com/librarysong/practice-cloud) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/practice-cloud/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/librarysong/practice-cloud/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/practice-cloud/network/members "分叉数")</span>

springCloud的简单整合



---

### 4. [solo-blog](https://github.com/librarysong/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/librarysong/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.swfcp.cn`](https://www.swfcp.cn "项目主页")</span>

宋维飞的个人博客 - 记录精彩的程序人生



---

### 5. [sell](https://github.com/librarysong/sell) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/sell/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/librarysong/sell/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/sell/network/members "分叉数")</span>

微信点餐平台开发



---

### 6. [librarysong.github.io](https://github.com/librarysong/librarysong.github.io) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/librarysong.github.io/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/librarysong/librarysong.github.io/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/librarysong.github.io/network/members "分叉数")</span>

个人博客



---

### 7. [JdbcTemplate](https://github.com/librarysong/JdbcTemplate) <kbd title="主要编程语言">Java</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/JdbcTemplate/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/librarysong/JdbcTemplate/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/JdbcTemplate/network/members "分叉数")</span>





---

### 8. [SpringBoot](https://github.com/librarysong/SpringBoot) <kbd title="主要编程语言">Shell</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/librarysong/SpringBoot/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/librarysong/SpringBoot/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/librarysong/SpringBoot/network/members "分叉数")</span>

My first SpringBoot Project

